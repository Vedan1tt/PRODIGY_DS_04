import pandas as pd
import matplotlib.pyplot as plt
from wordcloud import WordCloud

# ── STEP 1: LOAD DATA ───────────────────────────────────────
df = pd.read_csv("twitter_training.csv", header=None,
                 names=["id", "topic", "sentiment", "tweet"])

print("Shape:", df.shape)
print("\nFirst 3 rows:")
print(df.head(3))
print("\nSentiment types:", df["sentiment"].unique())

# ── STEP 2: CLEAN DATA ──────────────────────────────────────
# Remove rows with missing tweets
df = df.dropna(subset=["tweet"])

# Remove "Irrelevant" sentiment rows
df = df[df["sentiment"] != "Irrelevant"]

print("\nShape after cleaning:", df.shape)

# ── STEP 3: CHART 1 — Overall Sentiment Distribution ────────
sentiment_counts = df["sentiment"].value_counts()

colors = {"Positive": "steelblue", "Negative": "salmon", "Neutral": "gray"}
bar_colors = [colors.get(s, "gray") for s in sentiment_counts.index]

plt.figure(figsize=(7, 5))
plt.bar(sentiment_counts.index, sentiment_counts.values, color=bar_colors)
plt.title("Overall Sentiment Distribution")
plt.xlabel("Sentiment")
plt.ylabel("Number of Tweets")
plt.tight_layout()
plt.savefig("chart1_sentiment_distribution.png", dpi=150)
plt.show()
print("Chart 1 saved!")

# ── STEP 4: CHART 2 — Sentiment by Top 5 Brands ─────────────
top5_brands = df["topic"].value_counts().head(5).index
df_top5 = df[df["topic"].isin(top5_brands)]

sentiment_by_brand = df_top5.groupby(["topic", "sentiment"]).size().unstack(fill_value=0)

sentiment_by_brand.plot(
    kind="bar",
    figsize=(10, 5),
    color=["salmon", "gray", "steelblue"]
)
plt.title("Sentiment by Top 5 Brands/Topics")
plt.xlabel("Brand / Topic")
plt.ylabel("Number of Tweets")
plt.xticks(rotation=30)
plt.legend(title="Sentiment")
plt.tight_layout()
plt.savefig("chart2_sentiment_by_brand.png", dpi=150)
plt.show()
print("Chart 2 saved!")

# ── STEP 5: CHART 3 — Pie Chart of Sentiments ───────────────
plt.figure(figsize=(6, 6))
plt.pie(
    sentiment_counts.values,
    labels=sentiment_counts.index,
    autopct="%1.1f%%",
    colors=["steelblue", "salmon", "gray"],
    startangle=140
)
plt.title("Sentiment Share (Pie Chart)")
plt.tight_layout()
plt.savefig("chart3_sentiment_pie.png", dpi=150)
plt.show()
print("Chart 3 saved!")

# ── STEP 6: CHART 4 — Word Cloud for Positive Tweets ────────
positive_tweets = " ".join(df[df["sentiment"] == "Positive"]["tweet"].astype(str))

wordcloud = WordCloud(
    width=800, height=400,
    background_color="white",
    colormap="Blues",
    max_words=100
).generate(positive_tweets)

plt.figure(figsize=(10, 5))
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.title("Most Common Words in Positive Tweets")
plt.tight_layout()
plt.savefig("chart4_positive_wordcloud.png", dpi=150)
plt.show()
print("Chart 4 saved!")

# ── STEP 7: CHART 5 — Word Cloud for Negative Tweets ────────
negative_tweets = " ".join(df[df["sentiment"] == "Negative"]["tweet"].astype(str))

wordcloud2 = WordCloud(
    width=800, height=400,
    background_color="white",
    colormap="Reds",
    max_words=100
).generate(negative_tweets)

plt.figure(figsize=(10, 5))
plt.imshow(wordcloud2, interpolation="bilinear")
plt.axis("off")
plt.title("Most Common Words in Negative Tweets")
plt.tight_layout()
plt.savefig("chart5_negative_wordcloud.png", dpi=150)
plt.show()
print("Chart 5 saved!")

print("\nAll done!")
print("\nSummary:")
for s, c in sentiment_counts.items():
    print(f"  {s}: {c} tweets ({round(c/len(df)*100, 1)}%)")